#ifndef __ARM_MMU_H
#define __ARM_MMU_H

/* The ARM doesn't have a mmu context */
typedef struct { } mm_context_t;

#endif
