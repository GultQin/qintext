/*
 * linux/include/asm-arm/arch-nexuspci/param.h
 */
