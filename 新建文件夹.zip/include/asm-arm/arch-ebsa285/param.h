/*
 * linux/include/asm-arm/arch-ebsa285/param.h
 */
