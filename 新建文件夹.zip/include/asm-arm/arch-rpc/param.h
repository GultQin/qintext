/*
 * linux/include/asm-arm/arch-rpc/param.h
 */
