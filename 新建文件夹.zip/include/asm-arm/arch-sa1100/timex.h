/*
 * linux/include/asm-arm/arch-sa1100/timex.h
 *
 * SA1100 architecture timex specifications
 *
 * Copyright (C) 1998 
 */

/*
 * SA1100 timer
 */
#define CLOCK_TICK_RATE		3686400
#define CLOCK_TICK_FACTOR	80
