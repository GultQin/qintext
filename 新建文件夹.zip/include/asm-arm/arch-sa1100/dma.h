/*
 * linux/include/asm-arm/arch-sa1100/dma.h
 */
#ifndef __ASM_ARCH_DMA_H
#define __ASM_ARCH_DMA_H

#define MAX_DMA_ADDRESS		0xffffffff

/* No DMA (strictly, a lie :-) ) */
#define MAX_DMA_CHANNELS	0

#endif /* _ASM_ARCH_DMA_H */
