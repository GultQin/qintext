/*
 * linux/include/asm-arm/arch-cl7500/shmparam.h
 *
 * Copyright (c) 1999 Nexus Electronics Ltd
 */

/* The processor-centric definitions are OK.  */

