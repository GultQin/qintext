/*
 * linux/include/asm-arm/arch-cl7500/param.h
 *
 * Copyright (C) 1999 Nexus Electronics Ltd
 */

#define HZ 100
