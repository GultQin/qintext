#ifndef _ALPHA_CURRENT_H
#define _ALPHA_CURRENT_H

register struct task_struct *current __asm__("$8");

#endif /* !(_ALPHA_CURRENT_H) */
