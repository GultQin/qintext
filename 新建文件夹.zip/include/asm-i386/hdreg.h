/*
 *  linux/include/asm-i386/hdreg.h
 *
 *  Copyright (C) 1994-1996  Linus Torvalds & authors
 */

#ifndef __ASMi386_HDREG_H
#define __ASMi386_HDREG_H

typedef unsigned short ide_ioreg_t;

#endif /* __ASMi386_HDREG_H */
