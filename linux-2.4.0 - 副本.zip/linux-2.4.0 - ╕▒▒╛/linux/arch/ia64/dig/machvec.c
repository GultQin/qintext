#define MACHVEC_PLATFORM_NAME	dig
#include <asm/machvec_init.h>
